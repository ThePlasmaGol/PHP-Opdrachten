<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud</title>
    <style>
        body {
            background-image: url("img/wp3961353-pokemon-4k-wallpapers.jpg");
            background-attachment: fixed; /* Hiermee wordt de achtergrondafbeelding vastgezet */
            text-align: center;
            background-repeat: no-repeat;
            color: black;
            background-size: cover;
            justify-content: center;
        }
    </style>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
    // functie: Programma CRUD bier
    // auteur: Wigmans   

    // Initialisatie
    include 'functions.php';

    // Main

    // Aanroep functie 
    crudbier();
?>
</body>
</html>
