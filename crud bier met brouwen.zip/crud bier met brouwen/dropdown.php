<?php

//auteur: fadiga
// funtie: dropdown

include 'functions.php';

function dropdownbier(){

    //haal de brouwer data op uit de database
    $result = getData('brouwer');
    //cennect database
    // query $sql = SELECT * from brouwer 
    $conn = connectDb();
    //ophalen data

$text = "
<select name='brouwcode' id='brouwcode'>";

foreach ($result as $row){
    $text .= "<option value='$row[brouwcode]'>$row[naam]</option>\n";
}

$text .= "</select>";
echo $text;
}

if (isset($_POST['kies'])) {
        echo "$_POST[brouwcode]";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <?php dropdownbier(); ?>

        <input type="submit" value="kies" name="kies">


    </form>
</body>
</html>