<?php
// auteur: Wigmans
// functie: configuratiebestand

define("DATABASE", "bieren");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

define("CRUD_TABLE", "bier");

?>