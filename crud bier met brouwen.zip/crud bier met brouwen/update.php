<?php
    // functie: update bier
    // auteur: Wigmans

    require_once('functions.php');

    // Test of er op de wijzig-knop is gedrukt 
    if(isset($_POST['btn_wzg'])){

        // test of update gelukt is
        if(updatebier($_POST) == true){
            echo "<script>alert('bier is gewijzigd')</script>";
        } else {
            echo '<script>alert("bier is NIET gewijzigd")</script>';
        }
    }

    // Test of biercode is meegegeven in de URL
    if(isset($_GET['biercode'])){  
        // Haal alle info van de betreffende biercode $_GET['biercode']
        $biercode = $_GET['biercode'];
        $row = getbier($biercode);
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="wbiercodeth=device-wbiercodeth, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Wijzig bier</title>
</head>
<style>
        body{
        background-image: url("img/Schermafbeelding 2024-03-18 170453.png");
    text-align: center;
    background-repeat: no-repeat;
    background-size: cover;
    color: black;

    }
</style>
<body>
  <h2>Wijzig bier</h2>
  <form method="post">

<input type="hidden"  id="naam" name="biercode" required value="<?php echo $row['biercode']; ?>"><br>

    <label for="naam">Naam:</label>
    <input type="text"  id="naam" name="naam" required value="<?php echo $row['naam']; ?>"><br>

    <label for="soort">soort:</label>
    <input type="text" id="soort" name="soort" required value="<?php echo $row['soort']; ?>"><br>

    <label for="stijl">stijl:</label>
    <input type="text" id="stijl" name="stijl" required value="<?php echo $row['stijl']; ?>"><br>
    
    <label for="alcohol">alcohol:</label>
    <input type="text" id="alcohol" name="alcohol" required value="<?php echo $row['alcohol']; ?>"><br>
    
    <label for="brouwcode">brouwcode:</label>
    <input type="text" id="brouwcode" name="brouwcode" required value="<?php echo $row['brouwcode']; ?>"><br>

    <input type="submit" name="btn_wzg" value="Wijzig">
  </form>
  <br><br>
  <a href='main.php'>Home</a>
</body>
</html>

<?php
    } else {
        "Geen biercode opgegeven<br>";
    }
?>