<?php
// auteur: M Fadiga
// functie: Configuratie

define("DATABASE", "ziekmeldingen");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

define("CRUD_TABLE", "ziekmeldingen");

?>