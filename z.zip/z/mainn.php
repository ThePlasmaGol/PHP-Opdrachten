<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud</title>
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <h1>Dit is de Admin pagina</h1>
    <a href="mainn2.php">Leerling pagina</a>
    <br>
    <a href="mainn.php">Admin pagina</a>

<?php
    // auteur: M Fadiga
    // functie: main page crud product 

    // Initialisatie
    include 'functions.php';

    // Main

    // Roept functie aan
    crudziek();
?>
</body>
</html>
